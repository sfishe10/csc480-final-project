
  # Quiz Question Page Design

  This is a code bundle for Quiz Question Page Design. The original project is available at https://www.figma.com/design/LBQJ0C9yXXOwhOpJgdoggu/Quiz-Question-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  