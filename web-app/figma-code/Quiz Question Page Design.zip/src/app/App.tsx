import { useState } from 'react';

export default function App() {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [selectedImportance, setSelectedImportance] = useState<number | null>(null);

  const options = ['Option 1', 'Option 2', 'Option 3', 'Option 4'];

  return (
    <div 
      className="h-screen w-full flex flex-col overflow-hidden" 
      style={{ 
        backgroundColor: '#FAFAF8',
        fontFamily: "'Plus Jakarta Sans', 'Inter', sans-serif"
      }}
    >
      {/* Navigation Bar */}
      <nav className="flex items-center justify-between px-8 py-6">
        <h1 
          className="text-xl font-semibold" 
          style={{ color: '#1A1A2E' }}
        >
          Find Your Fetch
        </h1>
        <span 
          className="text-sm font-light"
          style={{ color: '#9CA3AF' }}
        >
          Question 1 of 10
        </span>
      </nav>

      {/* Progress Bar */}
      <div className="w-full" style={{ backgroundColor: '#E5E7EB', height: '3px' }}>
        <div 
          className="h-full transition-all duration-300"
          style={{ 
            backgroundColor: '#FF6B35', 
            width: '10%' 
          }}
        />
      </div>

      {/* Main Content - Centered Card */}
      <div className="flex-1 flex items-center justify-center px-4">
        <div 
          className="w-full max-w-2xl rounded-3xl p-12"
          style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08)',
          }}
        >
          {/* Question Label */}
          <div 
            className="text-xs font-light tracking-wider mb-6"
            style={{ color: '#FF6B35' }}
          >
            QUESTION 1
          </div>

          {/* Question Text */}
          <h2 
            className="text-center font-bold mb-8"
            style={{ 
              color: '#1A1A2E',
              fontSize: '28px',
              lineHeight: '1.3'
            }}
          >
            Question 1 here
          </h2>

          {/* Multiple Choice Options - 2x2 Grid */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => setSelectedOption(index)}
                className="py-4 px-6 rounded-2xl transition-all duration-200 font-medium"
                style={{
                  backgroundColor: selectedOption === index ? '#FF6B35' : '#FFFFFF',
                  color: selectedOption === index ? '#FFFFFF' : '#1A1A2E',
                  border: selectedOption === index ? '2px solid #FF6B35' : '2px solid #E5E7EB',
                }}
              >
                {option}
              </button>
            ))}
          </div>

          {/* Divider */}
          <div 
            className="w-full my-8"
            style={{ 
              height: '1px', 
              backgroundColor: '#E5E7EB' 
            }}
          />

          {/* Importance Section */}
          <div>
            <label 
              className="block text-center mb-4"
              style={{ 
                color: '#6B7280',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
              How important is this to you?
            </label>

            {/* Importance Selector Circles */}
            <div className="flex items-center justify-center gap-4 mb-3">
              {[1, 2, 3, 4, 5].map((num) => (
                <button
                  key={num}
                  onClick={() => setSelectedImportance(num)}
                  className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 font-semibold"
                  style={{
                    backgroundColor: selectedImportance === num ? '#4FACFE' : '#E5E7EB',
                    color: selectedImportance === num ? '#FFFFFF' : '#6B7280',
                  }}
                >
                  {num}
                </button>
              ))}
            </div>

            {/* Labels */}
            <div className="flex justify-between px-1">
              <span 
                className="text-xs"
                style={{ color: '#9CA3AF' }}
              >
                Not Important
              </span>
              <span 
                className="text-xs"
                style={{ color: '#9CA3AF' }}
              >
                Very Important
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
